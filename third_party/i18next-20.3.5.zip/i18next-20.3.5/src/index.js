import i18next from './i18next.js';

export default i18next;
