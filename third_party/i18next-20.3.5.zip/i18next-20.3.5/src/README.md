# i18next: learn once - translate everywhere

## visit ➡️ [i18next.com](https://www.i18next.com)

```js
import i18next from 'https://deno.land/x/i18next/index.js';
// or import i18next from 'https://raw.githubusercontent.com/i18next/i18next/master/src/index.js'
// or import i18next from 'https://cdn.jsdelivr.net/gh/i18next/i18next/src/index.js'
```
